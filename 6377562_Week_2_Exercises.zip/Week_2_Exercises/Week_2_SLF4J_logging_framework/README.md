## Digital Nurture Program 4.0 Java FSE Weekly Submissions

### Name : Sandipan Rakshit
### SuperSet ID : 6377562
### Email : sandipanrakshit6@gmail.com

### Week2: SLF4J logging framework