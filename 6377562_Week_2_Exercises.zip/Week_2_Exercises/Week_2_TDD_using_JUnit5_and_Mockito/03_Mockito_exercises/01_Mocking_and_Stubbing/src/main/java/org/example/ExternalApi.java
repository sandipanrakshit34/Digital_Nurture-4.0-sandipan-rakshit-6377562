package org.example;

public interface ExternalApi {
    String getData();
}
